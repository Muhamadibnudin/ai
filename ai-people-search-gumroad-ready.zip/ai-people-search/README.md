# AI People Search & Public Information Finder

A mobile-first public-information research tool. It searches public web/news sources and organizes results. It does **not** search private accounts, leaked databases, passwords, private home addresses, private phone numbers, or bypass authentication/CAPTCHA.

## 1. Requirements

- Node.js 18+ (20+ recommended)
- Internet connection
- Optional search/AI provider API keys

## 2. Run backend

```bash
cd backend
npm install
copy .env.example .env
# Linux/macOS: cp .env.example .env
npm start
```

API: `http://localhost:3000`

Test:

`http://localhost:3000/api/health`

## 3. Run frontend

For local development, serve the `frontend` directory with any static server. For example:

```bash
cd frontend
python -m http.server 5500
```

Open `http://localhost:5500`.

The default frontend API is `http://localhost:3000`. To change it, before loading the page run in the browser console:

```js
localStorage.setItem("apiBase","https://YOUR-BACKEND-DOMAIN")
```

Then reload.

## 4. Search providers

Without an external search API, the backend uses public Wikipedia search plus public news endpoints (GDELT and Google News RSS). These services have their own availability/rate limits.

For broader web search, configure a provider through `SEARCH_API_URL` and `SEARCH_API_KEY`. The exact request/response format varies by provider, so adapt `services/search.js` to that provider's documented API.

Never put provider secrets in `frontend/script.js`.

## 5. AI provider

AI is optional. Set:

```env
AI_API_URL=
AI_API_KEY=
AI_MODEL=
```

The example expects an OpenAI-compatible chat-completions style response. Adapt `services/ai.js` if your provider uses a different API.

## 6. Deploy

### Frontend
GitHub Pages can host `frontend/` as static files.

### Backend
Deploy `backend/` to a Node-compatible hosting provider. Set environment variables in the hosting dashboard. Do not commit `.env`.

After deployment, set the frontend API base using:

```js
localStorage.setItem("apiBase","https://YOUR-BACKEND-DOMAIN")
```

For a polished Gumroad release, replace this manual setting with a build-time `API_BASE` configuration.

## Privacy

The product is designed for public information research. It must not be marketed as a private-person data broker. Do not add features that reveal private home addresses, private phone/WhatsApp numbers, passwords, leaked databases, family records, or private account content.

## License

See LICENSE. If you sell modified versions, make sure your own license is compatible with all dependencies and APIs you use.
