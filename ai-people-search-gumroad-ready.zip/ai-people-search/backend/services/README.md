# Service modules

- `search.js`: public web search adapter + Wikipedia fallback
- `news.js`: GDELT and Google News RSS
- `social.js`: public search links; no private scraping
- `profiles.js`: public profile search links
- `ai.js`: optional OpenAI-compatible summarizer with deterministic fallback
