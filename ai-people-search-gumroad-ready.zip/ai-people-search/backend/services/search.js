const UA={"User-Agent":"AI-People-Search/1.0 public-research-tool"};
export async function collectSearch(q,mode){
  const out=[];
  if(process.env.SEARCH_API_URL){
    try{
      const u=new URL(process.env.SEARCH_API_URL);
      u.searchParams.set("q",q);
      const r=await fetch(u,{headers:{...UA,"Authorization":process.env.SEARCH_API_KEY?`Bearer ${process.env.SEARCH_API_KEY}`:""}});
      if(r.ok){
        const j=await r.json();
        const items=j.results||j.organic||j.data||[];
        for(const x of items.slice(0,30))out.push(normalize(x));
      }
    }catch(e){console.warn("Configured search provider failed:",e.message)}
  }
  // No-key fallback: Wikipedia's public search API.
  try{
    const u=`https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(q)}&format=json&origin=*`;
    const r=await fetch(u,{headers:UA}); if(r.ok){const j=await r.json();for(const x of (j.query?.search||[]).slice(0,10))out.push({
      type:"profile",title:x.title,snippet:String(x.snippet||"").replace(/<[^>]+>/g,""),url:`https://en.wikipedia.org/wiki/${encodeURIComponent(x.title.replaceAll(" ","_"))}`,date:"",names:[x.title],organizations:[],locations:[]
    })}
  }catch(e){console.warn("Wikipedia failed:",e.message)}
  return dedupe(out);
}
function normalize(x){return {type:x.type||"web",title:x.title||x.name||"Result",snippet:x.snippet||x.description||"",url:x.url||x.link||"",date:x.date||x.published||"",names:x.names||[],organizations:x.organizations||[],locations:x.locations||[],contactType:x.contactType}}
function dedupe(a){return a.filter((x,i)=>x.url&&a.findIndex(y=>y.url===x.url)===i)}
