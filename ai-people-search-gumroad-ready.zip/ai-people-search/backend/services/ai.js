export async function summarize(q,data){
  const total=(data.web?.length||0)+(data.news?.length||0)+(data.social?.length||0)+(data.profiles?.length||0);
  if(process.env.AI_API_URL && process.env.AI_API_KEY){
    try{
      const body={model:process.env.AI_MODEL||"default",messages:[
        {role:"system",content:"Summarize only evidence supplied in the JSON. Never invent personal data. Distinguish facts, claims and possible matches. Do not expose private personal data."},
        {role:"user",content:`Query: ${q}\nEvidence:\n${JSON.stringify(data).slice(0,50000)}`}
      ]};
      const r=await fetch(process.env.AI_API_URL,{method:"POST",headers:{"Content-Type":"application/json","Authorization":`Bearer ${process.env.AI_API_KEY}`},body:JSON.stringify(body)});
      if(r.ok){const j=await r.json();return j.choices?.[0]?.message?.content||fallback(q,total)}
    }catch(e){console.warn("AI provider failed:",e.message)}
  }
  return fallback(q,total);
}
function fallback(q,total){return `Public-source search completed for "${q}". ${total} candidate source records were collected. Review the News, Social, Profiles and Sources tabs and verify important information at the original websites. A matching name or username does not establish identity.`}
