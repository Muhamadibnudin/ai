export async function collectProfiles(q,mode){
  if(mode==="news")return[];
  return [
    {type:"profile",title:`LinkedIn public search for "${q}"`,snippet:"Open the public search result and verify the profile yourself.",url:`https://www.google.com/search?q=${encodeURIComponent(`site:linkedin.com/in "${q}"`)}`,names:[q],organizations:[],locations:[]},
    {type:"profile",title:`GitHub public search for "${q}"`,snippet:"Public code/profile search.",url:`https://github.com/search?q=${encodeURIComponent(q)}&type=users`,names:[q],organizations:[],locations:[]},
    {type:"profile",title:`General web search for "${q}"`,snippet:"Search public websites and profiles.",url:`https://www.google.com/search?q=${encodeURIComponent(`"${q}"`)}`,names:[q],organizations:[],locations:[]}
  ];
}