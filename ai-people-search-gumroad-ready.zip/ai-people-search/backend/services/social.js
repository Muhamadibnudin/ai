const platforms=[
  ["LinkedIn","linkedin.com/in/"],["GitHub","github.com/"],["YouTube","youtube.com/"],["Instagram","instagram.com/"],
  ["TikTok","tiktok.com/@"],["X","x.com/"],["Reddit","reddit.com/user/"],["Facebook","facebook.com/"],["Threads","threads.net/@"],["Pinterest","pinterest.com/"]
];
export async function collectSocial(q,mode){
  // This module does not scrape private profiles or bypass platform controls.
  // It creates public search links so the user can verify candidate profiles directly.
  if(mode==="news")return[];
  return platforms.map(([name,path])=>({
    type:"social",title:`Search ${name} for "${q}"`,snippet:`Public search link. A matching name/username is not proof of identity.`,url:`https://www.google.com/search?q=${encodeURIComponent(`site:${path}"${q}"`)}`,date:"",names:[q],organizations:[],locations:[]
  }));
}