export async function collectNews(q,mode){
  const out=[];
  // GDELT DOC 2.1 is a public news search endpoint.
  try{
    const u=`https://api.gdeltproject.org/api/v2/doc/doc?query=${encodeURIComponent(q)}&mode=artlist&maxrecords=25&format=json&sort=datedesc`;
    const r=await fetch(u);if(r.ok){
      const j=await r.json();
      for(const x of (j.articles||[]))out.push({
        type:"news",title:x.title||x.domain,snippet:x.seendate?`Published/seen: ${x.seendate}`:"",url:x.url||"",date:parseDate(x.seendate),names:[q],organizations:[],locations:[]
      });
    }
  }catch(e){console.warn("GDELT failed:",e.message)}
  // Google News RSS fallback/additional source.
  try{
    const u=`https://news.google.com/rss/search?q=${encodeURIComponent(q)}&hl=en-US&gl=US&ceid=US:en`;
    const xml=await (await fetch(u)).text();
    const items=[...xml.matchAll(/<item>([\s\S]*?)<\/item>/g)].slice(0,20);
    for(const m of items){
      const b=m[1], get=t=>{const z=b.match(new RegExp(`<${t}>([\\\\s\\\\S]*?)<\\/${t}>`));return z?decode(z[1]):""};
      const title=get("title"),link=get("link"),pub=get("pubDate");
      if(title&&link)out.push({type:"news",title,snippet:get("description"),url:link,date:pub?new Date(pub).toISOString().slice(0,10):"",names:[q],organizations:[],locations:[]});
    }
  }catch(e){console.warn("Google News RSS failed:",e.message)}
  return out.filter((x,i,a)=>x.url&&a.findIndex(y=>y.url===x.url)===i).slice(0,40);
}
function decode(s){return s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g,"$1").replace(/<[^>]+>/g,"").replace(/&amp;/g,"&").replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&lt;/g,"<").replace(/&gt;/g,">")}
function parseDate(s){if(!s)return"";const m=String(s).match(/^(\d{4})(\d{2})(\d{2})/);return m?`${m[1]}-${m[2]}-${m[3]}`:""}
