import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { collectSearch } from "./services/search.js";
import { collectNews } from "./services/news.js";
import { collectSocial } from "./services/social.js";
import { collectProfiles } from "./services/profiles.js";
import { summarize } from "./services/ai.js";

dotenv.config();
const app=express();
app.use(cors({origin:process.env.CORS_ORIGIN||"*"}));
app.use(express.json({limit:"1mb"}));

app.get("/api/health",(req,res)=>res.json({ok:true,service:"AI People Search",time:new Date().toISOString()}));

app.get("/api/search",async(req,res)=>{
  const q=String(req.query.q||"").trim();
  const mode=String(req.query.mode||"broad");
  if(!q)return res.status(400).json({error:"Query is required."});
  if(q.length>160)return res.status(400).json({error:"Query is too long."});
  try{
    const [web,news,social,profiles]=await Promise.all([
      collectSearch(q,mode),collectNews(q,mode),collectSocial(q,mode),collectProfiles(q,mode)
    ]);
    const sources=[...web,...news,...social,...profiles].filter((x,i,a)=>x.url&&a.findIndex(y=>y.url===x.url)===i).slice(0,80);
    const contacts=web.filter(x=>x.contactType==="business");
    const overview=buildOverview(q,[...web,...profiles,...social]);
    const confidence=score(sources);
    const identity=identityMatch(q,sources);
    const summary=await summarize(q,{web,news,social,profiles,overview,identity});
    res.json({query:q,mode,generatedAt:new Date().toISOString(),summary,confidence,identity,overview,contacts,news,social,profiles,sources});
  }catch(err){console.error(err);res.status(500).json({error:"Search failed. Check backend logs and provider configuration."})}
});
app.listen(process.env.PORT||3000,()=>console.log(`AI People Search API running on port ${process.env.PORT||3000}`));

function uniq(a){return [...new Set(a.filter(Boolean))]}
function buildOverview(q,items){
  const names=uniq(items.flatMap(x=>x.names||[])).slice(0,12);
  const locations=uniq(items.flatMap(x=>x.locations||[])).slice(0,12);
  const organizations=uniq(items.flatMap(x=>x.organizations||[])).slice(0,12);
  const websites=uniq(items.map(x=>x.url).filter(u=>/^https?:/i.test(u))).slice(0,12);
  return {names:[q,...names].filter((x,i,a)=>a.indexOf(x)===i).slice(0,12),locations,organizations,websites};
}
function score(sources){
  let s=0;
  if(sources.length>=3)s+=25; else if(sources.length)s+=10;
  const domains=new Set(sources.map(x=>{try{return new URL(x.url).hostname}catch{return""}}).filter(Boolean));
  s+=Math.min(30,domains.size*5);
  const dated=sources.filter(x=>x.date).length;s+=Math.min(20,dated*2);
  const authoritative=sources.filter(x=>/gov|edu|reuters|apnews|bbc|wikipedia|linkedin/i.test(x.url||"")).length;s+=Math.min(25,authoritative*5);
  return {score:Math.min(100,s),reasons:[`${sources.length} sources`,`${domains.size} domains`,`${dated} dated results`]};
}
function identityMatch(q,sources){
  const exact=sources.filter(x=>(x.title||"").toLowerCase().includes(q.toLowerCase())).length;
  if(exact>=4)return {level:"High confidence",reason:"Several public sources directly contain the search term. This is not proof that all results belong to one person."};
  if(exact>=1)return {level:"Possible match",reason:"At least one public source matches the search term; additional context is needed."};
  return {level:"Uncertain",reason:"No strong identity signal was established from the available public sources."};
}