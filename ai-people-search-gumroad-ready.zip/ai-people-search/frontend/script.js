const API = (window.API_BASE || localStorage.getItem("apiBase") || "http://localhost:3000").replace(/\/$/,"");
let currentReport=null;
const $=s=>document.querySelector(s);
const esc=v=>String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
const empty=m=>`<div class="empty">${esc(m)}</div>`;
function setStatus(msg,show=true){$("#status").textContent=msg;$("#status").classList.toggle("hidden",!show)}
function historyRender(){
  const h=JSON.parse(localStorage.getItem("peopleSearchHistory")||"[]");
  $("#history").innerHTML=h.length?h.map(x=>`<div class="history-row"><span>${esc(x)}</span><button data-history="${esc(x)}">Search</button></div>`).join(""):empty("No local search history.");
}
function saveHistory(q){let h=JSON.parse(localStorage.getItem("peopleSearchHistory")||"[]");h=[q,...h.filter(x=>x!==q)].slice(0,12);localStorage.setItem("peopleSearchHistory",JSON.stringify(h));historyRender()}
function sourceItem(x){return `<div class="item"><div><span class="badge">${esc(x.type||"SOURCE")}</span>${x.date?`<span class="badge">${esc(x.date)}</span>`:""}</div><h3>${esc(x.title||x.name||"Untitled")}</h3>${x.snippet?`<p>${esc(x.snippet)}</p>`:""}${x.url?`<a href="${esc(x.url)}" target="_blank" rel="noopener noreferrer">Open source ↗</a>`:""}</div>`}
function render(r){
  currentReport=r;$("#results").classList.remove("hidden");$("#resultTitle").textContent=r.query;$("#foundAt").textContent=`Found ${new Date(r.generatedAt).toLocaleString()}`;
  $("#score").textContent=r.confidence.score;
  $("#summary").innerHTML=`<p>${esc(r.summary)}</p>${r.confidence.reasons.map(x=>`<span class="badge">${esc(x)}</span>`).join("")}`;
  const o=r.overview||{};
  $("#tab-overview").innerHTML=`<div class="card"><div class="card-title">PERSON / ENTITY OVERVIEW</div>
    <div class="kv"><b>Query</b><span>${esc(r.query)}</span></div>
    <div class="kv"><b>Identity match</b><span><span class="badge ${r.identity.level==="High confidence"?"good":"warn"}">${esc(r.identity.level)}</span>${esc(r.identity.reason)}</span></div>
    <div class="kv"><b>Names found</b><span>${(o.names||[]).map(esc).join(", ")||"Not found"}</span></div>
    <div class="kv"><b>Locations</b><span>${(o.locations||[]).map(esc).join(", ")||"Not found"}</span></div>
    <div class="kv"><b>Organizations</b><span>${(o.organizations||[]).map(esc).join(", ")||"Not found"}</span></div>
    <div class="kv"><b>Websites</b><span>${(o.websites||[]).map(x=>`<a target="_blank" rel="noopener" href="${esc(x)}">${esc(x)}</a>`).join("<br>")||"Not found"}</span></div>
  </div>`;
  $("#tab-social").innerHTML=r.social.length?r.social.map(sourceItem).join(""):empty("No public social/profile result was found.");
  $("#tab-news").innerHTML=r.news.length?r.news.map(sourceItem).join(""):empty("No news result was found.");
  $("#tab-profiles").innerHTML=r.profiles.length?r.profiles.map(sourceItem).join(""):empty("No professional/profile result was found.");
  $("#tab-contacts").innerHTML=r.contacts.length?r.contacts.map(sourceItem).join(""):empty("No public business contact information was found.");
  $("#tab-sources").innerHTML=r.sources.length?r.sources.map(sourceItem).join(""):empty("No sources.");
  const years={};r.news.forEach(n=>{const y=(n.date||"Unknown").slice(0,4);(years[y]??=[]).push(n)});$("#tab-timeline").innerHTML=Object.keys(years).sort().reverse().map(y=>`<div class="timeline-year">${esc(y)}</div>${years[y].map(sourceItem).join("")}`).join("")||empty("No timeline data.");
}
async function doSearch(q,mode="broad"){
  setStatus("Searching public sources…");$("#results").classList.add("hidden");
  try{
    const res=await fetch(`${API}/api/search?q=${encodeURIComponent(q)}&mode=${encodeURIComponent(mode)}`);
    const data=await res.json(); if(!res.ok)throw new Error(data.error||"Search failed");
    render(data);saveHistory(q);setStatus("",false);
  }catch(e){setStatus(`Error: ${e.message}`,true)}
}
$("#searchForm").addEventListener("submit",e=>{e.preventDefault();doSearch($("#query").value.trim(),document.querySelector('input[name="mode"]:checked').value)});
document.addEventListener("click",e=>{
  const b=e.target.closest(".tab");if(b){document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));document.querySelectorAll(".tab-panel").forEach(x=>x.classList.remove("active"));b.classList.add("active");$("#tab-"+b.dataset.tab).classList.add("active")}
  const h=e.target.closest("[data-history]");if(h){$("#query").value=h.dataset.history;doSearch(h.dataset.history)}
});
$("#clearHistory").onclick=()=>{localStorage.removeItem("peopleSearchHistory");historyRender()};
$("#themeBtn").onclick=()=>{document.body.classList.toggle("dark");localStorage.setItem("dark",document.body.classList.contains("dark"))};
if(localStorage.getItem("dark")==="true")document.body.classList.add("dark");historyRender();

function download(name,type,text){const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([text],{type}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
$("#exportJson").onclick=()=>currentReport&&download("people-search-report.json","application/json",JSON.stringify(currentReport,null,2));
$("#exportTxt").onclick=()=>currentReport&&download("people-search-report.txt","text/plain",JSON.stringify(currentReport,null,2));
$("#exportHtml").onclick=()=>{if(!currentReport)return;const r=currentReport;download("people-search-report.html","text/html",`<!doctype html><meta charset="utf-8"><title>${esc(r.query)}</title><style>body{font:15px Arial;max-width:900px;margin:40px auto}a{color:#315efb}.item{padding:12px 0;border-bottom:1px solid #ddd}</style><h1>${esc(r.query)}</h1><p>${esc(r.summary)}</p>${r.sources.map(sourceItem).join("")}`)}
